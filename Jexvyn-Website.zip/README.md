# Jexvyn Website

Responsive static website for the Jexvyn Discord bot.

## Files
- `index.html` — landing page
- `privacy.html` — Privacy Policy draft
- `terms.html` — Terms of Service draft

## Before publishing
1. Replace `YOUR_BOT_CLIENT_ID` in `index.html` with your Discord application's client ID.
2. Add the official Jexvyn support/contact details to the legal pages.
3. Verify the Privacy Policy against the actual bot source code and hosting/logging configuration. The current draft reflects your statement that no database is used, but should be checked before publishing.
4. Upload these files to the root of a GitHub repository.
5. Open Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

No build step is required; this is plain HTML/CSS/JS.
